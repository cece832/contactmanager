import React, { useState, useEffect } from 'react';
import { X, Plus } from 'lucide-react';
import { db } from '../firebase';
import { collection, query, where, getDocs, updateDoc, doc, addDoc } from 'firebase/firestore';
import { Group, Person } from '../types';

interface GroupSelectorProps {
  onClose: () => void;
  person: Person;
  userId: string;
}

export function GroupSelector({ onClose, person, userId }: GroupSelectorProps) {
  const [groups, setGroups] = useState<Group[]>([]);
  const [selectedGroups, setSelectedGroups] = useState<string[]>(person.groupIds || []);
  const [isCreatingGroup, setIsCreatingGroup] = useState(false);
  const [newGroup, setNewGroup] = useState({ name: '', description: '' });

  useEffect(() => {
    const fetchGroups = async () => {
      const q = query(collection(db, 'groups'), where('userId', '==', userId));
      const querySnapshot = await getDocs(q);
      const groupsData: Group[] = [];
      querySnapshot.forEach((doc) => {
        groupsData.push({ id: doc.id, ...doc.data() } as Group);
      });
      setGroups(groupsData);
    };

    fetchGroups();
  }, [userId]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await updateDoc(doc(db, 'persons', person.id), {
        groupIds: selectedGroups
      });
      onClose();
    } catch (error) {
      console.error('Error updating person groups:', error);
    }
  };

  const handleCreateGroup = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const docRef = await addDoc(collection(db, 'groups'), {
        ...newGroup,
        userId,
      });
      
      // Add the new group to the selected groups
      setSelectedGroups(prev => [...prev, docRef.id]);
      
      // Add the new group to the local groups list
      setGroups(prev => [...prev, { id: docRef.id, ...newGroup, userId } as Group]);
      
      // Reset the form and close the creation interface
      setNewGroup({ name: '', description: '' });
      setIsCreatingGroup(false);
    } catch (error) {
      console.error('Error creating group:', error);
    }
  };

  const toggleGroup = (groupId: string) => {
    setSelectedGroups(prev => 
      prev.includes(groupId)
        ? prev.filter(id => id !== groupId)
        : [...prev, groupId]
    );
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg max-w-md w-full p-6">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-semibold">Add to Groups</h2>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
            <X size={24} />
          </button>
        </div>
        
        {/* Create New Group Button */}
        {!isCreatingGroup && (
          <button
            onClick={() => setIsCreatingGroup(true)}
            className="w-full mb-4 flex items-center justify-center space-x-2 py-2 px-4 border-2 border-dashed border-gray-300 rounded-md text-gray-600 hover:border-blue-500 hover:text-blue-600 transition-colors"
          >
            <Plus size={20} />
            <span>Create New Group</span>
          </button>
        )}

        {/* Create New Group Form */}
        {isCreatingGroup && (
          <form onSubmit={handleCreateGroup} className="mb-6 border-b pb-6">
            <div className="space-y-4">
              <div>
                <label htmlFor="groupName" className="block text-sm font-medium text-gray-700">
                  Group Name *
                </label>
                <input
                  type="text"
                  id="groupName"
                  required
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  value={newGroup.name}
                  onChange={e => setNewGroup(prev => ({ ...prev, name: e.target.value }))}
                />
              </div>
              <div>
                <label htmlFor="groupDescription" className="block text-sm font-medium text-gray-700">
                  Description
                </label>
                <textarea
                  id="groupDescription"
                  rows={3}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  value={newGroup.description}
                  onChange={e => setNewGroup(prev => ({ ...prev, description: e.target.value }))}
                />
              </div>
              <div className="flex space-x-2">
                <button
                  type="submit"
                  className="flex-1 bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
                >
                  Create Group
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setIsCreatingGroup(false);
                    setNewGroup({ name: '', description: '' });
                  }}
                  className="flex-1 bg-gray-100 text-gray-700 py-2 px-4 rounded-md hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2"
                >
                  Cancel
                </button>
              </div>
            </div>
          </form>
        )}

        {/* Existing Groups List */}
        <form onSubmit={handleSubmit}>
          <div className="space-y-4 max-h-60 overflow-y-auto">
            {groups.length === 0 ? (
              <p className="text-gray-500 text-center py-4">No groups created yet.</p>
            ) : (
              groups.map(group => (
                <label key={group.id} className="flex items-center space-x-3">
                  <input
                    type="checkbox"
                    checked={selectedGroups.includes(group.id)}
                    onChange={() => toggleGroup(group.id)}
                    className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                  />
                  <div>
                    <span className="text-gray-900 block">{group.name}</span>
                    {group.description && (
                      <span className="text-gray-500 text-sm">{group.description}</span>
                    )}
                  </div>
                </label>
              ))
            )}
          </div>
          <div className="mt-6">
            <button
              type="submit"
              className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
            >
              Save Changes
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}