export interface Person {
  id: string;
  name: string;
  role: string;
  organization: string;
  notes: string;
  userId: string;
  groupIds: string[];
  imageUrl?: string;
  linkedinUrl?: string;
  phoneNumber?: string;
  email?: string;
}

export interface Group {
  id: string;
  name: string;
  description: string;
  userId: string;
}

export interface User {
  uid: string;
  email: string | null;
}