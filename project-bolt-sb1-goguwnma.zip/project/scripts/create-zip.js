import AdmZip from 'adm-zip';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import fs from 'fs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const projectRoot = join(__dirname, '..');

// Initialize zip file
const zip = new AdmZip();

// Excluded patterns
const excludePatterns = [
  'node_modules',
  'dist',
  '.env',
  '.git',
  'PROJECTZIP.zip',
  'project.zip'
];

function shouldExclude(path) {
  return excludePatterns.some(pattern => path.includes(pattern));
}

function addDirectoryToZip(dirPath, zip) {
  const files = fs.readdirSync(dirPath);

  files.forEach(file => {
    const filePath = join(dirPath, file);
    const stats = fs.statSync(filePath);
    
    if (shouldExclude(filePath)) {
      return;
    }

    if (stats.isDirectory()) {
      addDirectoryToZip(filePath, zip);
    } else {
      const fileData = fs.readFileSync(filePath);
      // Make the path relative to project root
      const zipPath = filePath.replace(projectRoot + '/', '');
      // Add file with UTF-8 encoding for text files to make them searchable
      const isTextFile = /\.(js|jsx|ts|tsx|css|html|json|md|txt)$/i.test(zipPath);
      zip.addFile(zipPath, fileData, '', isTextFile ? 0o644 : 0o755);
    }
  });
}

// Add files to zip
addDirectoryToZip(projectRoot, zip);

// Write zip file with compression level 5 for better searchability
zip.writeZip(join(projectRoot, 'PROJECTZIP.zip'), { compression: 5 });

console.log('PROJECTZIP.zip file created successfully!');